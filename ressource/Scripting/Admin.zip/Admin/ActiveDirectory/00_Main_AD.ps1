# Script principal de l'Administration Active Directory
# Lancement du Script en tant que Administrateur + Fenêtre Maximale

Start-Process PowerShell -ArgumentList "C:\Admin\ActiveDirectory\00_Menu_AD.ps1" -Verb RunAs -WindowStyle Maximized